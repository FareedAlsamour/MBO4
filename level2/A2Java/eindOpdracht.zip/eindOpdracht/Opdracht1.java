package eindOpdracht;

public class Opdracht1 {
    public static void main(String[] args){
        String formule = "1000*200*350+(300-100-20-11+1)-(200*3-4-5-1+1+3+5*2)";
        Integer resultaat = FormuleBereken.bereken(formule);
        System.out.println(formule + " = "+resultaat);


 /* hier kun je de andere formules ook nog uitwerken en
 je eigen formules toevoegen
 */
    }

}
